import React from 'react';
import ReactDOM from 'react-dom/client';
import BharatFaceHome from './BharatFaceHome';
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<BharatFaceHome />);