export default function BharatFaceHome() {
  return <h1>Welcome to BharatFace.ai</h1>;
}